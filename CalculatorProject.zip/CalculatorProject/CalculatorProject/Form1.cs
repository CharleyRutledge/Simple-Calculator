namespace CalculatorProject
{
    public partial class Calc : Form
    {
        public Calc()
        {
            InitializeComponent();
        }
        //Clears the text from the output screen
        private void button8_Click(object sender, EventArgs e)
        {
            this.lblOutput.ResetText();
        }
        //outputs the number "0" to the screen by using the "+" operator,
        // the operator lets you enter other numbers such as 0,1,2,3 etc
        // if there is no "+", the output sticks on "0".
        private void button1_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "0";
        }

        //sets the output screen as "1". same logic applies as above.
        private void btnOne_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "1";
        }

        // empty function. affects form when deleted. do not delete
        private void lblOutput_Click(object sender, EventArgs e)
        {

        }

        //sets the output screen as "2". same logic applies as "0"..
        private void btnTwo_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "2";
        }

        //sets the output screen as "3". same logic applies as  "0".
        private void btnThree_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "3";
        }

        //sets the output screen as "4". same logic applies as  "0".
        private void btnFour_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "4";
        }

        //sets the output screen as "5". same logic applies as  "0".
        private void btnFive_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "5";
        }

        //sets the output screen as "6". same logic applies as  "0".
        private void btnSix_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "6";
        }

        //sets the output screen as "7". same logic applies as  "0".
        private void btnSeven_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "7";
        }

        //sets the output screen as "8". same logic applies as  "0".
        private void btnEight_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "8";
        }

        //sets the output screen as "9". same logic applies as  "0".
        private void btnNine_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + "9";
        }

        // empty function. affects form when deleted. do not delete
        private void label1_Click(object sender, EventArgs e)
        {

        }

        //LOGIC of operators

        //when the user enters numbers, the operator, when pressed displays above the output area.
        //if the output does not contain any empty text. it outputs what is stored on the output screen
        //to the First num screen sabout the main output screen.
        //the output text field is reset.
        // an error occurs when you enter an operator immediatly after another has been selected is presented, it clears the number entered (error).
        //with the logic applied the number is kept on the screen while only the operator changes.
        //outout screen text is reset.
        private void btnPlus_Click(object sender, EventArgs e)
        {
            this.lblOperator.Text = "+";
            if (this.lblOutput.Text != "")
            {
                this.lblfirst_num.Text = this.lblOutput.Text;
            }
           
            this.lblOutput.ResetText();
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            this.lblOperator.Text = "-";
            if (this.lblOutput.Text != "")
            {
                this.lblfirst_num.Text = this.lblOutput.Text;
            }
            
            this.lblOutput.ResetText();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            this.lblOperator.Text = "*";
            if (this.lblOutput.Text != "")
            {
                this.lblfirst_num.Text = this.lblOutput.Text;
            }

            this.lblOutput.ResetText();
        }

        private void btnDivi_Click(object sender, EventArgs e)
        {
            this.lblOperator.Text = "%";
            if (this.lblOutput.Text != "")
            {
                this.lblfirst_num.Text = this.lblOutput.Text;
            }

            this.lblOutput.ResetText();
        }


        //Equals logic

        //variables of type double is defined
        // tryParse will convert the number into it double-precision floating-point number equivalent. will return true or false.
        private void btnEquals_Click(object sender, EventArgs e)
        {
            double Fnum, Snum , total = 0;
            double.TryParse(this.lblfirst_num.Text, out Fnum);
            double.TryParse(this.lblOutput.Text, out Snum);

            //calculates total by checking if the user eneterd the correct operator and if this is true, returns the total by adding the 2 numbers.
            if (this.lblOperator.Text == "+")
            {
                total = Fnum + Snum;
                
            }
            if (this.lblOperator.Text == "-")
            {
                total = Fnum - Snum;

            }
            if (this.lblOperator.Text == "%")
            {
                total = Fnum / Snum;

            }
            if (this.lblOperator.Text == "*")
            {
                total = Fnum * Snum;

            }
            //converts the total into a string which is read and dispayed in the output text box. the operator and first_num lables are reset
            this.lblOutput.Text = total.ToString();
            this.lblfirst_num.ResetText();
            this.lblOperator.ResetText();
        }

        //sets the output screen as ".". same logic applies as  "0". this will allow for decimal calculations.
        private void btnDec_Click(object sender, EventArgs e)
        {
            this.lblOutput.Text = this.lblOutput.Text + ".";
        }
    }
}